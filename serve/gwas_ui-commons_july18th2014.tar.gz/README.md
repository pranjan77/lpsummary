#UI Common
**Version 0.0.1**
Common user interface components and libraries for the KBase Project.

##Contents
 * KBase Widget API
 * Widget Library
 * Landing Pages
 * KBase Labs Templates

##The Widget API
TODO: Add documentation

###Testing the Widget API

##Widget Library

##Landing Pages

##KBase Labs Template

##Contributors

 * [Neal Conrad](mailto:nconrad@mcs.anl.gov)
 * [Matt Henderson](mailto:mhenderson@lbl.gov)
 * [Shiran Pasternak](mailto:shiran@cshl.edu)
 * [Bill Riehl](mailto:wjriehl@lbl.gov)
 * [Jim Thomason](mailto:thomason@cshl.edu)
