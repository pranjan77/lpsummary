(function( $, undefined ){

	$.kbWidget("landingPageCard", 'kbaseWidget') {
		version: "1.0.0",

		options: {
		},

		init: function(options) {
			this._super(options);

		},

		render: function(options) {

		},
	}


})( jQuery );